/*
 BFS(grafo G, nodo u)
 Crear una cola Q
 Q.push(u)
 marcar u como visitado
 Mientras Q != vacío
 t = Q.pop()
 Si t es lo que buscamos
 return t
 Para todas las arista e incidentes en t:
 o = G.opuesto(t,e)
 Si o no está marcado
 marcar o
 Q.push(o)*/

#include "DFS.h"
DFS::DFS()
{
    
    
}

