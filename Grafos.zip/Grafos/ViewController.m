//
//  ViewController.m
//  Grafos
//
//  Created by Gad Levy on 10/7/13.
//  Copyright (c) 2013 Gad Levy. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    
}
@end



@implementation ViewController

-(id) init {
    
    
    return self;
}

- (void)viewDidLoad
{

    
    
    // insert code here...
    Grafo *g = new Grafo();
    g->creaGrafo();
    g->Dijkstra(g->regresaVertice("R"),g->regresaVertice("U"));
    
    

    
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
