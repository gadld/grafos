//
//  Arista.h
//  GrafosAput
//
//  Created by LourdesMG on 3/26/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#ifndef ARI
#define ARI
   // if x.h hasn't been included yet...
#define __Grafo_INCLUDED__
#include <iostream>
#include "Vertice.h"
#include <vector>




using namespace std;


class DFS {
    
private:
    vector<Vertice *>Q;
public:
    DFS();
   // DFS(Grafo *g,Vertice *v);
    
    
    
};

#endif