//
//  Grafo.cpp
//  GrafosAput
//
//  Created by LourdesMG on 3/26/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//GAD LEVY
//A01017986

#include "Grafo.h"


Grafo::Grafo()
{
    
    
}




void Grafo::creaGrafo()
{

    Vertice *a = new Vertice();
    a->setDato("A");
    Vertice *b = new Vertice();
    b->setDato("B");
    Vertice *c = new Vertice();
    c->setDato("C");
    Vertice *d = new Vertice();
    d->setDato("D");
    Vertice *e = new Vertice();
    e->setDato("E");
    Vertice *f = new Vertice();
    f->setDato("F");
    Vertice *g = new Vertice();
    g->setDato("G");
    Vertice *h = new Vertice();
    h->setDato("H");
    Vertice *i = new Vertice();
    i->setDato("I");
    Vertice *k = new Vertice();
    k->setDato("K");
    Vertice *l = new Vertice();
    l->setDato("L");
    Vertice *m = new Vertice();
    m->setDato("M");
    Vertice *n = new Vertice();
    n->setDato("N");
    Vertice *o = new Vertice();
    o->setDato("O");
    Vertice *p = new Vertice();
    p->setDato("P");
    Vertice *q = new Vertice();
    q->setDato("Q");
    Vertice *r = new Vertice();
    r->setDato("R");
    Vertice *s = new Vertice();
    s->setDato("S");
    Vertice *t = new Vertice();
    t->setDato("T");
    Vertice *u = new Vertice();
    u->setDato("U");
    Vertice *v = new Vertice();
    v->setDato("V");
    Vertice *w = new Vertice();
    w->setDato("W");
    Vertice *x = new Vertice();
    x->setDato("X");
    Vertice *y = new Vertice();
    y->setDato("Y");
    Vertice *z = new Vertice();
    z->setDato("Z");
    Vertice *aa = new Vertice();
    aa->setDato("AA");
    Vertice *bb = new Vertice();
    bb->setDato("BB");
    Vertice *cc = new Vertice();
    cc->setDato("CC");
    Vertice *dd = new Vertice();
    dd->setDato("DD");
    Vertice *ee = new Vertice();
    ee->setDato("EE");

    Vertice *gg = new Vertice();
    gg->setDato("GG");
    
    
    todos.push_back(a);
    todos.push_back(b);
    todos.push_back(c);
    todos.push_back(d);
    todos.push_back(e);
    todos.push_back(f);
    todos.push_back(g);
    todos.push_back(h);
    todos.push_back(i);

    
    todos.push_back(k);
    todos.push_back(l);
    todos.push_back(m);
    todos.push_back(n);
    todos.push_back(o);
    todos.push_back(p);
    todos.push_back(q);
    todos.push_back(r);
    todos.push_back(s);
    todos.push_back(t);
    todos.push_back(u);
    todos.push_back(v);
    todos.push_back(w);
    todos.push_back(x);
    todos.push_back(y);
    todos.push_back(z);
    todos.push_back(aa);
    todos.push_back(bb);
    todos.push_back(cc);
    todos.push_back(dd);
    todos.push_back(ee);
    todos.push_back(gg);
    
    Arista *ab = new Arista(a, b, 5);
    lista.push_back(ab);
    Arista *bc = new Arista(b, c, 1);
    lista.push_back(bc);
    Arista *cd = new Arista(c, d, 2);
    lista.push_back(cd);
    Arista *de = new Arista(d, e, 1);
    lista.push_back(de);
    Arista *ef = new Arista(e, f, 1);
    lista.push_back(ef);
    Arista *ag = new Arista(a, g, 3);
    lista.push_back(ag);
    Arista *ch = new Arista(c, h, 4);
    lista.push_back(ch);
    Arista *hi = new Arista(h, i, 1);
    lista.push_back(hi);
    Arista *di = new Arista(d, i, 5);
    lista.push_back(di);
      
   
    Arista *fk = new Arista(f, k, 3);
    lista.push_back(fk);
    Arista *gl = new Arista(g, l, 2);
    lista.push_back(gl);
    Arista *lm = new Arista(l, m, 1);
    lista.push_back(lm);
    Arista *mn = new Arista(m, n, 1);
    lista.push_back(mn);
    Arista *hn = new Arista(h, n, 3);
    lista.push_back(hn);
    Arista *no = new Arista(n, o, 8);
    lista.push_back(no);
    Arista *io = new Arista(i, o, 1);
    lista.push_back(io);
    Arista *op = new Arista(o, p, 7);
    lista.push_back(op);
    
    Arista *pq = new Arista(p, q, 1);
    lista.push_back(pq);
    Arista *kq = new Arista(k, q, 4);
    lista.push_back(kq);
    Arista *lr = new Arista(l, r, 10);
    lista.push_back(lr);
    Arista *rs = new Arista(r, s, 1);
    lista.push_back(rs);
    Arista *ms = new Arista(m, s, 2);
    lista.push_back(ms);
    Arista *st = new Arista(s, t, 7);
    lista.push_back(st);
    Arista *nt = new Arista(n, t, 3);
    lista.push_back(nt);
    Arista *rw = new Arista(r, w, 2);
    lista.push_back(rw);
    Arista *wx = new Arista(w, x, 3);
    lista.push_back(wx);
    Arista *sx = new Arista(s, x, 1);
    lista.push_back(sx);
    Arista *pu = new Arista(p, u, 2);
    lista.push_back(pu);
    Arista *uv = new Arista(u, v, 1);
    lista.push_back(uv);
    Arista *qv = new Arista(q, v, 3);
    lista.push_back(qv);
    Arista *uz = new Arista(u, z, 1);
    lista.push_back(uz);
    Arista *zaa = new Arista(z, aa, 3);
    lista.push_back(zaa);
    Arista *vaa = new Arista(v, aa, 4);
    lista.push_back(vaa);
    Arista *yz = new Arista(y, z, 7);
    lista.push_back(yz);
    Arista *wbb = new Arista(w, bb, 5);
    lista.push_back(wbb);
    Arista *bbcc = new Arista(bb, cc, 1);
    lista.push_back(bbcc);
    Arista *xcc = new Arista(x, cc, 1);
    lista.push_back(xcc);
    Arista *ccdd = new Arista(cc, dd, 1);
    lista.push_back(ccdd);
    Arista *ddee = new Arista(dd, ee, 2);
    lista.push_back(ddee);
    Arista *yee = new Arista(y, ee, 2);
    lista.push_back(yee);
    Arista *aagg = new Arista(aa, gg, 1);
    lista.push_back(aagg);

    string inicio = "";
    cout << "Ingresa inicio:\n>";
    getline(cin, inicio);
    
    string fin = "";
    cout << "Ingresa fin:\n>";
    getline(cin, fin);

    

    //Dijkstra(regresaVertice(inicio),regresaVertice(fin));

    
    //dfs(m);
}
Vertice* Grafo::regresaVertice (string input)
{
    for (int i=0; i<todos.size(); i++) {
        if (todos[i]->getDato()==input) {
            return todos[i];
        }
    }
    cout<<"Vertice no encontrado";
    return todos[0];
}
vector<Vertice *> Grafo::vecinos(Vertice *x)
{
    int i=0;
    Arista *a;
    vector<Vertice *> vv;
    
    for(i=0; i< lista.size(); i++)
    {
        a=lista[i];
        if(a->getOrigen()->getDato() == x->getDato())
        {
            vv.push_back(a->getDestino());
        }
        if(a->getDestino()->getDato() == x->getDato())
        {
            vv.push_back(a->getOrigen());
        }
    }

    return vv;
}

int Grafo::grado(Vertice *v)
{
    int grado = 0;
    Arista *a;
    for(int i=0;i<lista.size();i++)
    {
        a=lista[i];
        if(a->getOrigen()->getDato() == v->getDato())
        {
            grado++;
        }
        if(a->getDestino()->getDato() == v->getDato())
        {
            grado++;
        }
    }
    return grado;
}
void Grafo::dfs(Vertice *u)
{
    for (int j=0; j<lista.size(); j++) {
        Arista *a=lista[j];
        if (a->getOrigen()==u) {
            if (a->getEstatus()==NOVISITADA) {
                a->setEstatus(DESCUBRE);
                Vertice *dest=a->getDestino();
                cout<<dest->getDato()<<"\n";
                dfs(dest);
            }
            Vertice *dest=a->getDestino();
            cout<<"repeti "<<dest->getDato()<<"\n";
        }
    }
}
void Grafo::Dijkstra (Vertice* inicio,Vertice *final)
{

    
    for (int i=0; i<todos.size(); i++) {
        todos[i]->setDistancia(1000000);
        todos[i]->setAnterior(NULL);
    }
    inicio->setDistancia(0);
    
    for (int x=0; x<todos.size();) {
        //xcout<<"GAD size "<<todos.size()<<"\n";
        Vertice *u = todos[0];

        int p = 0;
        for (int i=1; i<todos.size(); i++) {
            Vertice *gad=todos[i];
            //cout<<"todos"<<todos[i]->getDato()<<"\n";
            if (gad->getDistancia()<u->getDistancia()) {
                u=todos[i];
                p=i;
                
            }
        }
       // cout<<"GAD size "<<todos.size()<<"uuu"<<u->getDato()<<"\n";
        todos.erase(todos.begin()+p);
        //cout<<"borrando"<<todos.size()<<"y x="<<x<<"\n";
        
        if (u==final) {

            Vertice *aux=u;
            while (aux->getAnterior()) {
                cout<<aux->getDato()<<"\n";
                aux=aux->getAnterior();
            }
            
        }

        vector<Vertice *>vecinosVect=vecinos(u);

        
        int empezarAca=0;
        for (int i=0; i<vecinosVect.size(); i++) {
            
            Arista *a=NULL;
            vector<Arista *> copialista=lista;
            
            
            for (int j=empezarAca; j<copialista.size(); j++) {
                if (copialista[j]->getOrigen()==u || copialista[j]->getDestino()==u) {
                    //cout<<"\nentre j veces"<<j<< "arista destino ="<<lista[i]->getDestino()->getDato();
                    a=copialista[j];
                    empezarAca=j+1;
                    //cout<<"\n arista origen ="<<a->getOrigen()->getDato()<< " destino="<<a->getDestino()->getDato();
                    break;
                }//ya encontre mi arista
            }//cierro la busqueda de arista
            
            
            int alt=u->getDistancia()+a->getPeso();
            if (alt < vecinosVect[i]->getDistancia()) {
                if (u==a->getOrigen()) {
                    a->getDestino()->setAnterior(u);
                    a->getDestino()->setDistancia(alt);
                    //cout<<"\nactualizando"<<a->getDestino()->getDato()<<"con valor de "<<alt<<"\n";

                }
                else{
                    a->getOrigen()->setAnterior(u);
                    a->getOrigen()->setDistancia(alt);
                    //cout<<"\nactualizando"<<a->getOrigen()->getDato()<<"con valor de "<<alt<<"\n";
                    

                }
            }
        }
    
    }
    
}

